OK     = '1'
ADD    = '2'
APPEND = '3'
