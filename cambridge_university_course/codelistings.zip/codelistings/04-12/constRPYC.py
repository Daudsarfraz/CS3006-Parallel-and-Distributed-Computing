SERVER = "localhost"
PORT   = 12345
