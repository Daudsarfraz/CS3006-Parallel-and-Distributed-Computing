ENTER   = '1'
ALLOW   = '2'
RELEASE = '3'
